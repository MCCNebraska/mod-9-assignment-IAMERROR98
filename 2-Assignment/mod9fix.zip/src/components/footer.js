import React from 'react';


const Footer = props => {

    return(
        <>
            <h6>
                warning: Dunwich Animal Shelter is not responsible
               for any bouts of madness, paranoia, anxiety, Antisocial Personality Disorder,
               Psychosis, or any abnormal mental behavior caused by adopting one of our dogs.
            </h6>
            
            <h6>
                If you have any questions please don't contact us
            </h6>
        </>
    )
}

export default Footer;
