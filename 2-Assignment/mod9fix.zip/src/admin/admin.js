//
import Header from "../components/header";
import { Button } from "@material-ui/core";
import { useHistory } from "react-router-dom";
//import { useNavigate } from "react-router-dom";

const Admin = () => {
    const history = useHistory();
    //const c = useNavigate();

    const test = () => {
        history.push("/")

    }

    return(
        <>
            <Header title="Overseer Controll"/>

            <Button size="small" color="primary" onClick={test}></Button>
        </>
    )
};

export default Admin;