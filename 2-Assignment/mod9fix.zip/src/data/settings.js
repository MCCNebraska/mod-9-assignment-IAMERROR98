const settings =
    {

    apidata: 'http://localhost:3001/Dogs'

    };

export default settings;